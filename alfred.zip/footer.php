<!-- footer //-->
<div style = "background: black; width: 100%; margin:0; padding:0">
    <div style = "height: 32px"></div>
    <div style = "width: 100%; height: 50px; color: gray; font-family: Arial; font-size: 12px; text-align: center; margin: auto; position: relative;">
        &copy; <?php print date("Y", time()); ?> Alfred's Catering. <a href = "http://www.rivertigris.net?r=ac" title = "Austin TX Web Design Company" style = "color:#9d282f;">Web Design</a> by River Tigris.
    </div>
</div>