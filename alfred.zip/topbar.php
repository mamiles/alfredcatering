<div id="top-100" style = "padding-bottom: 12px;">
    <div class="container">
        <div class="row">
            <div id="top">
                <div class="bar-logo">
                    <a href="<?php print $URL; ?>"><img style = "margin-top: 8px; min-width: 250px" src="<?php print $URL; ?>/alfreds-catering-logo.png" alt="Alfred's Catering Logo"/></a>
                </div>
                <div class="menu" style = "margin-top: 8px; box-shadow: 0px 0px 5px #000; padding: 5px; padding-top: 10px; padding-bottom: 10px; vertical-align: middle; background: black; border-radius: 5px;">
                    <div id="showRightPush">Menu</div>
                </div>
                <p style = "box-shadow: 0 0 5px #000; background: black; border-radius: 10px; width: 325px; padding-left: 16px;"><span style = 'color: #c31824; font-weight: bold; display:inline-block'>Email Us:</span> <a href = "mailto:catering@alfredcatering.com" style = "color: #fff;">catering@alfredcatering.com</a></p>
            </div>
        </div>
    </div>
</div>