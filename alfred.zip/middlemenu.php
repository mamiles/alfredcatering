<ul>

<li><a href="mainmenu.pdf"> <img src="wp-content/themes/360developers/images/tooth.png" alt="#"
      onmouseover="this.src='wp-content/themes/360developers/images/tooth.png';"
      onmouseout="this.src='wp-content/themes/360developers/images/tooth.png';"/><span>Corporate Menu</span></a></li>

<li><a href="mainmenu-wedding.pdf"> <img src="wp-content/themes/360developers/images/tooth.png" alt="#"
      onmouseover="this.src='wp-content/themes/360developers/images/tooth.png';"
      onmouseout="this.src='wp-content/themes/360developers/images/tooth.png';"/><span>Weddings Menu</span></a></li>
      
<li><a href="HorsdoeuvreSelectionsAllTiers.pdf"> <img src="wp-content/themes/360developers/images/tooth.png" alt="#"
      onmouseover="this.src='wp-content/themes/360developers/images/tooth.png';"
      onmouseout="this.src='wp-content/themes/360developers/images/tooth.png';"/><span>Hors d'oeuvres Menu</span></a></li>
      
<li><a href="testimonials.php"> <img src="wp-content/themes/360developers/images/tooth.png" alt="#"
      onmouseover="this.src='wp-content/themes/360developers/images/tooth.png';"
      onmouseout="this.src='wp-content/themes/360developers/images/tooth.png';"/><span>Testimonials</span></a></li>
      
<li><a href="https://www.facebook.com/pg/alfredscatering/photos/?tab=album&album_id=563412960403126"> <img src="wp-content/themes/360developers/images/tooth.png" alt="#"
      onmouseover="this.src='wp-content/themes/360developers/images/tooth.png';"
      onmouseout="this.src='wp-content/themes/360developers/images/tooth.png';"/><span>Photo Gallery</span></a></li>
      
<li><a href="mailto:catering@alfredcatering.com"> <img src="wp-content/themes/360developers/images/tooth.png" alt="#"
      onmouseover="this.src='wp-content/themes/360developers/images/tooth.png';"
      onmouseout="this.src='wp-content/themes/360developers/images/tooth.png';"/><span>Contact</span></a></li>

</ul>